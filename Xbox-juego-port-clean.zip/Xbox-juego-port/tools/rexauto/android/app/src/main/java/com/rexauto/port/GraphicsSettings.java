package com.rexauto.port;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Graphics / performance options exposed by the launcher. Each maps 1:1 to a
 * ReXGlue runtime cvar; the native side reads settings.txt and hands every
 * line over as --key=value before the runtime is constructed.
 */
public final class GraphicsSettings {
    private final SharedPreferences prefs;

    public GraphicsSettings(Context ctx) {
        prefs = ctx.getSharedPreferences("graphics", Context.MODE_PRIVATE);
    }

    // --- knobs (defaults tuned for a mid-range Adreno/Mali phone) -----------
    /** Internal render scale: 1 = native 720p (fastest), 2 = 2x, 3 = 3x. */
    public int resolutionScale() { return Math.max(1, Math.min(3, prefs.getInt("resolution_scale", 1))); }
    public void setResolutionScale(int v) { prefs.edit().putInt("resolution_scale", Math.max(1, Math.min(3, v))).apply(); }

    public boolean vsync() { return prefs.getBoolean("vsync", true); }
    public void setVsync(boolean v) { prefs.edit().putBoolean("vsync", v).apply(); }

    /** bilinear (cheap) | cas (sharpen) | fsr (upscale) */
    public String presentEffect() { return prefs.getString("present_effect", "bilinear"); }
    public void setPresentEffect(String v) { prefs.edit().putString("present_effect", v).apply(); }

    /** Guest video mode (what the game thinks the TV is). 720p is the safe pick. */
    public int videoWidth() { return prefs.getInt("video_mode_width", 1280); }
    public int videoHeight() { return prefs.getInt("video_mode_height", 720); }
    public void setVideoMode(int w, int h) { prefs.edit().putInt("video_mode_width", w).putInt("video_mode_height", h).apply(); }

    /** Keep 4:3/16:9 letterbox instead of stretching to the phone's aspect. */
    public boolean letterbox() { return prefs.getBoolean("present_letterbox", true); }
    public void setLetterbox(boolean v) { prefs.edit().putBoolean("present_letterbox", v).apply(); }

    /** Tolerant dispatcher: log-and-return on an unregistered indirect call
     *  instead of aborting (what the desktop `play <name>.cmd` does). */
    public boolean tolerant() { return prefs.getBoolean("tolerant", true); }
    public void setTolerant(boolean v) { prefs.edit().putBoolean("tolerant", v).apply(); }

    /** Screen orientation while playing: landscape (default) | portrait | auto. */
    public String orientation() { return prefs.getString("orientation", "landscape"); }
    public void setOrientation(String v) { prefs.edit().putString("orientation", v).apply(); }

    /**
     * Experimental GPU driver (PanVK on Mali, Turnip on Adreno): OFF by
     * default, per the user rule that risky core changes live behind a
     * switch he turns on himself. The driver picker (GraphicsDialog)
     * refuses to open while this is off. Default Sistema: the custom
     * driver only loads when a zip was imported AND selected AND this is on.
     */
    public boolean experimentalGpuDriver() { return prefs.getBoolean("experimental_gpu_driver", false); }
    public void setExperimentalGpuDriver(boolean v) { prefs.edit().putBoolean("experimental_gpu_driver", v).apply(); }

    /**
     * Game language (ISO 639 code, e.g. "es", "en"). First run auto-detects
     * from the Android system locale and stores it, so the game speaks the
     * phone's language without any visible setting — an official port has no
     * language screen. The Xbox 360 game reads it via ExGetXConfigSetting
     * (XCONFIG_USER_LANGUAGE) backed by the kernel cvar user_language
     * (1 = English … 5 = Spanish); user_country matches it for locale.
     */
    public String language() {
        String v = prefs.getString("language", null);
        if (v == null) {
            v = Locale.getDefault().getLanguage();
            if (v == null || v.isEmpty()) v = "es";
            prefs.edit().putString("language", v).apply();
        }
        return v;
    }
    public void setLanguage(String v) { prefs.edit().putString("language", v == null ? "es" : v).apply(); }

    /** XLanguage id for an ISO 639 code (xcontent.h: es=5, en=1, …). */
    public static int languageId(String lang) {
        if (lang == null) return 1;
        switch (lang) {
            case "es": return 5;
            case "ja": return 2;
            case "de": return 3;
            case "fr": return 4;
            case "it": return 6;
            case "ko": return 7;
            case "pt": return 9;
            case "ru": return 12;
            case "pl": return 11;
            default: return 1;
        }
    }

    /**
     * XCountry id matching a language. Only es→31 (ES) is verified against
     * the kernel table (xam_locale.cpp); everything else keeps 103 (US),
     * which was the previous default — no behavior change for other languages.
     */
    public static int countryId(String lang) {
        if ("es".equals(lang)) return 31;
        return 103;
    }

    /**
     * Performance preset. Each one is a bundle of runtime cvars on top of the
     * knobs above; "performance" is the default because a phone GPU is roughly a
     * tenth of the Xenos+CPU budget the game was tuned for.
     *
     *   performance  -- 720p guest mode, 1x scale, no anisotropic filtering, no
     *                   memexport readback (GPU->CPU sync stall every frame),
     *                   occlusion queries answered with a constant instead of a
     *                   GPU round-trip, vsync via FIFO (no tearing, no busy loop),
     *                   texture cache capped so it never evicts mid-level.
     *   balanced     -- like performance but 4x anisotropic and real occlusion
     *                   queries (some games use them for lens flares / LOD).
     *   accuracy     -- SDK defaults (what the desktop port runs).
     */
    public String preset() { return prefs.getString("preset", "performance"); }
    public void setPreset(String v) { prefs.edit().putString("preset", v).apply(); }

    /** Frame-rate cap 0 = off. 30 halves GPU work for games that already ran at 30 on the 360. */
    public int fpsCap() { return prefs.getInt("fps_cap", 0); }
    public void setFpsCap(int v) { prefs.edit().putInt("fps_cap", v).apply(); }

    /** Extra raw cvars (advanced): "key=value" per line. */
    public String extra() { return prefs.getString("extra", ""); }
    public void setExtra(String v) { prefs.edit().putString("extra", v == null ? "" : v).apply(); }

    public Map<String, String> asCvars() {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("resolution_scale", Integer.toString(resolutionScale()));
        m.put("draw_resolution_scale_x", Integer.toString(resolutionScale()));
        m.put("draw_resolution_scale_y", Integer.toString(resolutionScale()));
        m.put("vsync", Boolean.toString(vsync()));
        m.put("present_effect", presentEffect());
        m.put("video_mode_width", Integer.toString(videoWidth()));
        m.put("video_mode_height", Integer.toString(videoHeight()));
        m.put("present_letterbox", Boolean.toString(letterbox()));

        // (Caza P-H4.) Vulkan feature requirements, gated on the experimental
        // GPU driver switch: the native side defaults
        // vulkan_require_fragment_stores_and_atomics=true (vulkan_device.cpp)
        // and PanVK on Mali lacks both stores+atomics features, so with the
        // switch on both cvars go false and SetupContext / CreateIfSupported
        // boot the device instead of hard-failing (draws that actually use
        // fragment memexport still fail individually). With the switch off
        // the system driver runs and fragment keeps the SDK default (true).
        // Vertex stays false in both cases: its SDK default is already
        // false, and Mali may lack it, so emitting true would risk the
        // system-driver boot too. A hand-written line in "extra" still wins
        // (it is applied after this block).
        boolean expDriver = experimentalGpuDriver();
        m.put("vulkan_require_fragment_stores_and_atomics", Boolean.toString(!expDriver));
        m.put("vulkan_require_vertex_pipeline_stores_and_atomics", "false");

        // DLC license (hunt 2 DLC, P0-1): the game checks bit 0 of the
        // GLOBAL license mask (XamContentGetLicenseMask returns only this
        // cvar, default 0) before enabling any DLC. The per-package mask
        // (0x1, written into the .header by InstallContent) does NOT feed
        // that check, so without this line the game enumerates the DLCs
        // but never enables them. 0xFFFFFFFF covers bit 0 with margin.
        // Always on (all presets): licensing has nothing to do with graphics.
        m.put("license_mask", "4294967295");

        // --- preset bundle -------------------------------------------------
        String p = preset();
        if (!p.equals("accuracy")) {
            // no per-frame GPU->CPU copy of memexport buffers; almost no title
            // reads them back on the CPU, and the sync costs a full frame stall
            m.put("readback_memexport", "false");
            m.put("vulkan_readback_memexport", "false");
            m.put("vulkan_readback_resolve", "false");
            // texture cache: SDK defaults (384/768/24). v1.4.1 used half
            // (192/384/16) and with the DXT->uncompressed 4x fallback the
            // cache held ~48 MB DXT-equivalent before evicting: constant
            // evict + re-decode, the texture errors on the phone (hunt
            // app-java P0-2 + nativo-sdk P0-2, both verified in code).
            m.put("texture_cache_memory_limit_soft", "384");
            m.put("texture_cache_memory_limit_hard", "768");
            m.put("texture_cache_memory_limit_render_to_texture", "24");
            // shader compile off the render thread; present frames that used a
            // placeholder pipeline instead of dropping them (the skip drops
            // whole frames during shader warm-up, which reads as stutter;
            // v1.4.1 proved the engine default alone does not hold because
            // this settings value overrode it)
            m.put("async_shader_compilation", "true");
            m.put("vulkan_async_skip_incomplete_frames", "false");
            // present: FIFO_RELAXED when the driver offers it (FIFO with
            // tearing allowed if a frame arrives late -- the SDK default,
            // and the value that actually ships here), else strict FIFO.
            // Mailbox/immediate stay off: they keep the GPU busy rendering
            // frames the panel never shows -- pure heat on a phone.
            m.put("vulkan_allow_present_mode_immediate", "false");
            m.put("vulkan_allow_present_mode_mailbox", "false");
            m.put("vulkan_allow_present_mode_fifo_relaxed", "true");
            // log I/O on the render/guest threads is not free
            // log_level=info while diagnosing (hunt P1-2): warning hid the
            // info lines the FASE5 checklist needs (presenter geometry,
            // STFS fd, affinity pin, pipelines created) -- that is why the
            // v1.4.1 log the user sent was warnings-only.
            m.put("log_level", "info");
            m.put("log_high_frequency_kernel_calls", "false");
            m.put("vulkan_log_debug_messages", "false");
            m.put("gpu_debug_markers", "false");
            // dynamic rendering: no VkRenderPass objects, fewer pipeline variants
            m.put("vulkan_dynamic_rendering", "true");
        }
        if (p.equals("performance")) {
            m.put("anisotropic_override", "0");          // 0 = off
            m.put("occlusion_query_enable", "false");    // constant answer, no GPU round-trip
            m.put("native_2x_msaa", "false");            // resolve 2xMSAA as 1x
            m.put("gamma_render_target_as_unorm16", "false"); // 8-bit gamma RTs: half the bandwidth
        } else if (p.equals("balanced")) {
            m.put("anisotropic_override", "3");          // 4x
        }
        if (fpsCap() > 0) m.put("env.REX_FPS_CAP", Integer.toString(fpsCap()));
        // "env.NAME=value" lines are exported as environment variables by the
        // native side (the dispatcher reads REX_HEAL_DISCOVER via getenv).
        if (tolerant()) m.put("env.REX_HEAL_DISCOVER", "1");
        // Game language: the 360 game reads XCONFIG_USER_LANGUAGE (cvar
        // user_language) at boot; Spanish resources exist in the bundle
        // (localization_spanish.isg, *.es.srt). Before the manual "extra"
        // lines so a hand-written user_language= there still wins.
        String lang = language();
        m.put("user_language", Integer.toString(languageId(lang)));
        m.put("user_country", Integer.toString(countryId(lang)));
        for (String line : extra().split("\n")) {
            line = line.trim();
            int eq = line.indexOf('=');
            if (line.startsWith("#") || eq <= 0) continue;
            m.put(line.substring(0, eq).trim(), line.substring(eq + 1).trim());
        }
        return m;
    }

    /** Writes settings.txt for the native side. */
    public void write(Context ctx) throws IOException {
        File f = GameFiles.settingsFile(ctx);
        File parent = f.getParentFile();
        if (parent != null) parent.mkdirs();
        Map<String, String> cvars = asCvars();
        // (Ronda 4, R4-G3.) settings.txt is the ONLY channel for cvars with
        // no UI knob (e.g. xbmovie_probe=true for the video probe: no Java
        // surface writes it), and users hand-edit the file for them. This
        // used to rewrite the file from prefs alone, silently dropping
        // every hand-added line on each Graphics-dialog OK / import /
        // launchGame. Preserve lines whose key we do not write (ours win
        // for keys we own; the "extra" box already covers those durably).
        // A read failure here must never break the write: fall through to
        // a prefs-only file, as before.
        List<String> preserved = new ArrayList<>();
        if (f.isFile()) {
            try (BufferedReader r = new BufferedReader(new FileReader(f))) {
                String line;
                while ((line = r.readLine()) != null) {
                    String t = line.trim();
                    if (t.isEmpty() || t.startsWith("#")) continue;
                    int eq = t.indexOf('=');
                    if (eq <= 0) continue;
                    String key = t.substring(0, eq).trim();
                    if (!cvars.containsKey(key)) {
                        preserved.add(key + "=" + t.substring(eq + 1).trim());
                    }
                }
            } catch (IOException ignored) {
                preserved.clear();
            }
        }
        try (PrintWriter w = new PrintWriter(new FileWriter(f, false))) {
            w.println("# written by the rexauto Android launcher - one cvar per line");
            for (Map.Entry<String, String> e : cvars.entrySet()) {
                w.println(e.getKey() + "=" + e.getValue());
            }
            if (!preserved.isEmpty()) {
                w.println("# hand-added lines preserved from the previous settings.txt");
                for (String line : preserved) w.println(line);
            }
            // (Ronda 5, auditor F — R5-F4.) PrintWriter traga los errores de
            // E/S: sin checkError() un settings.txt truncado o vacio (disco
            // lleno, almacenamiento retirado) parecia escrito y el arranque
            // siguiente corria con los defaults del SDK sin avisar.
            if (w.checkError()) throw new IOException("write " + f);
        }
    }
}
